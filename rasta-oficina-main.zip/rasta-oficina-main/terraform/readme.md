terraform-oci/
│
├── main.tf
├── variables.tf
├── outputs.tf
└── provider.tf


OBS: Arquivo main.tf
Defina os recursos OCI, incluindo VCN, Subnet, Compute, Autonomous Database, Object Storage, e Load Balancer
